package com.eventbooking.entity.event_enum;

public enum BookingPaymentStatus {
	
	PENDING,PAID,FAILED

}
