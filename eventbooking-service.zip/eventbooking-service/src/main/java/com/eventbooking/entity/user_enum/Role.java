package com.eventbooking.entity.user_enum;

public enum Role {
	
		 USER, ORGANIZER, ADMIN
		 }
