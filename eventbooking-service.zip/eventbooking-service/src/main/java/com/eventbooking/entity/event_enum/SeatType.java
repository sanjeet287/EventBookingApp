package com.eventbooking.entity.event_enum;

public enum SeatType {
	
	REGULAR,VIP

}
