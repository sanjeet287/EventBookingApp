package com.eventbooking.config;

public class RabbitMQConfigConstant {

	public static final String EXCHANGE = "booking.exchange";
	public static final String ROUTING_KEY = "payment.confirmed";
	public static final String QUEUE = "booking.payment.queue";

}
