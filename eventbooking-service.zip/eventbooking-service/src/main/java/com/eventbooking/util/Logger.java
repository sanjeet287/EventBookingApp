package com.eventbooking.util;

public class Logger {

}
