package com.evenbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.eventbooking.EventbookingServiceApplication;

@SpringBootTest(classes = EventbookingServiceApplication.class)
class EventbookingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
