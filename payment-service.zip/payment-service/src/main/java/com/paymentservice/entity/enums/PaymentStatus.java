package com.paymentservice.entity.enums;

public enum PaymentStatus {

	SUCCESS, FAILED, PENDING,INTIATED

}
